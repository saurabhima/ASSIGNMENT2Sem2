#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <ctime> 
#include <time.h>
#include <iostream>
using namespace std;
int clientid;
char clientname[20];
time_t logintime;
int sockfd, portno, n;
void error(const char *msg)
{
    perror(msg);
    exit(0);
}
void my_handler(int s){
           printf("Caught signal %d\n",s);
           //cout<<"send_close_connection\n";
           char clos[50];
           cout<<clientid<<"\n";
           snprintf(clos, sizeof(clos), "%d", clientid);
           
           strcat(clos,":CLOSECONN");
           cout<<clos<<"\n";
           int n = write(sockfd,clos,strlen(clos));
           if (n < 0) 
            error("ERROR writing to socket");
           cout<<"Closing Socket\n";
           close(sockfd);
           cout<<"Exiting..\n";
           exit(1); 
 
}



void printmenue()
{
    char menu[10][100];
    strcpy(menu[0],"1. Print Own ID\n");
    strcpy(menu[1],"2. Print Active Clients\n");
    strcpy(menu[2],"3. Send Message to Client\n");
    strcpy(menu[3],"4. Exit\n");
    for (int x=0;x<4;x++)
    {
    cout<<menu[x]; 
    }
    
}
void processforid(char *buffer)
{

char *token;
int clientidtemp;
int logintimetemp;
char logintimetempchar[20];
char clientnametemp[20];
char *lev2token;
token=strtok(buffer,":");
char clientidpart[100];
strcpy(clientidpart,token);
//cout<<clientidpart<<"\n";
token=strtok(NULL,":");
char clientnamepart[100];
strcpy(clientnamepart,token);
//cout<<clientnamepart<<"\n";
token=strtok(NULL,":");
char clientlogintimepart[100];
strcpy(clientlogintimepart,token);
//cout<<clientlogintimepart<<"\n";
lev2token=strtok(clientidpart,"-");
char code[20];
strcpy(code,lev2token);
lev2token=strtok(NULL,"-");
clientidtemp=atoi(lev2token);
if (strcmp(code,"CLIENTID")==0)
{
    clientid=clientidtemp;
    cout<<"Client ID Set by Server-->"<<clientid<<"\n";
}

lev2token=strtok(clientnamepart,"-");

strcpy(code,lev2token);
lev2token=strtok(NULL,"-");
strcpy(clientnametemp,lev2token);
if (strcmp(code,"CLIENTNAME")==0)
{
    strcpy(clientname,clientnametemp);
    cout<<"Client Name Set by Server-->"<<clientname<<"\n";
}

lev2token=strtok(clientlogintimepart,"-");

strcpy(code,lev2token);
lev2token=strtok(NULL,"-");
strcpy(logintimetempchar,lev2token);
if (strcmp(code,"LOGINTIME")==0)
{
    logintimetemp=atoi(logintimetempchar);
    logintime=(time_t)logintimetemp;
    cout<<"Client Login Time Set by Server-->"<<logintime<<"\n";
}




}
void printownid()
{
cout<<"ClientID-->"<<clientid<<"\n";
cout<<"Client Name-->"<<clientname<<"\n";
cout<<"Login Time-->";
char buf[16];
std::tm * ptm = std::localtime(&logintime);
char buffer[32];
std::strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm); 
cout<<buffer<<"\n";
}
int check_error(int sockfd,char buffer[])
{
    if((strstr(buffer, "Error") != NULL)&&(strstr(buffer, "Exiting") != NULL)) {
    close(sockfd);
    exit(0);
    }
}
void send_ack(int sockfd)
{
    
    //cout<<"send_ack_fn\n";
    char ack[]="ACK";
    int n = write(sockfd,ack,strlen(ack));
    if (n < 0) 
         error("ERROR writing to socket");
}

void getclientids(int sockfd)
{
    cout<<"Processing GEt Client Details\n";
    char clientidstr[50];
    snprintf(clientidstr, sizeof(clientidstr), "%d", clientid);
    strcat(clientidstr,":GETCLIENTSID");    
    int n = write(sockfd,clientidstr,strlen(clientidstr));
           if (n < 0) 
            error("ERROR writing to socket");
    char buffer[1000];
    bzero(buffer,1000);
    
    n=read(sockfd,buffer,999);
    if (n < 0) 
         error("ERROR reading from socket");
    printf("%s\n",buffer);

}
int main(int argc, char *argv[])
{
    
    signal (SIGINT,my_handler);
    struct sockaddr_in serv_addr;
    struct hostent *server;
    system("clear");
    
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    char message[100];
       
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
    

    
    
    char buffer[1000];
    bzero(buffer,1000);
    //n = recv(sockfd, buffer, 255, 0);
    n=read(sockfd,buffer,999);
    if (n < 0) 
         error("ERROR reading from socket");
    printf("%s\n",buffer);
    check_error(sockfd,buffer);
    send_ack(sockfd);
    bzero(buffer,1000);
    //n = recv(sockfd, buffer, 255, 0);
    n=read(sockfd,buffer,999);
    
    
    if (n < 0) 
         error("ERROR reading from socket");
    else 
        {
            
            char * st;
            st=buffer;
            //cout<<st<<"\n";
            processforid(buffer);
        }
    while(1)
    {
        printmenue();
        int choice;
        cin>>choice;
        cout<<choice<<"\n";
        switch(choice)
        {
            case 1:printownid();
                   break;
            case 2:getclientids(sockfd);
                   break; 
            case 4:close(sockfd);
                   exit(0);
                   break;
            
        }
    }
    
    close(sockfd);
    return 0;
}