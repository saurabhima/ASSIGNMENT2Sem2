#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <boost/algorithm/string.hpp>
#include <iostream>
using namespace std;
int clientid;
void error(const char *msg)
{
    perror(msg);
    exit(0);
}
void printmenue()
{
    char menu[10][100];
    strcpy(menu[0],"1. Print Own ID\n");
    strcpy(menu[1],"2. Print Active Clients\n");
    strcpy(menu[2],"3. Send Message to Client\n");
    strcpy(menu[3],"4. Exit\n");
    for (int x=0;x<4;x++)
    {
    cout<<menu[x]; 
    }
    
}
void processforid(char *buffer)
{

char *token;
int clientidtemp;

token=strtok(buffer,":");
char code[100];
strcpy(code,token);


token= strtok( NULL, ":" );
clientidtemp=atoi(token);



if (strcmp(code,"CLIENTID")==0)
{
    clientid=clientidtemp;
    cout<<"Client ID Set by Server-->"<<clientid<<"\n";
}
}
void printownid()
{
cout<<"ClientID-->"<<clientid<<"\n";
}

void send_ack(int sockfd)
{
    
    cout<<"send_ack_fn\n";
    char ack[]="ACK";
    int n = write(sockfd,ack,strlen(ack));
    if (n < 0) 
         error("ERROR writing to socket");
}
int main(int argc, char *argv[])
{
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    char message[100];
       
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
    

    
    /*n = write(sockfd,message,strlen(message));
    if (n < 0) 
         error("ERROR writing to socket");*/
    char buffer[1000];
    bzero(buffer,1000);
    //n = recv(sockfd, buffer, 255, 0);
    n=read(sockfd,buffer,999);
    if (n < 0) 
         error("ERROR reading from socket");
    printf("%s\n",buffer);
    
    send_ack(sockfd);
    bzero(buffer,1000);
    //n = recv(sockfd, buffer, 255, 0);
    n=read(sockfd,buffer,999);
    
    
    if (n < 0) 
         error("ERROR reading from socket");
    else 
        {
            cout<<"You reached here\n";
            char * st;
            st=buffer;
            cout<<st<<"\n";
            processforid(buffer);
        }
    while(1)
    {
        printmenue();
        int choice;
        cin>>choice;
        switch(choice)
        {
            case 1:printownid();
        }
    }
    
    close(sockfd);
    return 0;
}