
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
using namespace std;

char* random_name_generator()
{
char *rand_name=(char *) malloc(sizeof(char) * 10);
int i=0;
for ( i = 0; i < 10; i++)
{
	rand_name[i]=rand() % 25 + 66;
}
rand_name[i]='\0';
cout<<rand_name<<"\n";
return (rand_name);
}


