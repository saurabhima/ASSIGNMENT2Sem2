#include  <stdio.h>
#include  <stdlib.h>
#include  <sys/types.h>
#include  <sys/ipc.h>
#include  <sys/shm.h>
#include <iostream>
using namespace std;


void  main(int  argc, char *argv[])
{
 
int number=rand();
cout<<number<<"\n";
}
